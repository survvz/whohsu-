/*
import { Message } from 'eris';

import { IMClient } from '../../client';
import { BotCommand, CommandGroup } from '../../types';
import { Command, Context } from '../Command';

export default class extends Command {
	public constructor(client: IMClient) {
		super(client, {
			name: BotCommand.report,
			aliases: [],
			group: CommandGroup.Report,
			guildOnly: false
		});
	}

	public async action(message: Message): Promise<any> {
		this.sendReply(message, 'Not implemented');
	}
}
*/
