export class RolePermission {
	public roleId: string;
	public command: string;
	public createdAt?: Date;
	public updatedAt?: Date;
}
